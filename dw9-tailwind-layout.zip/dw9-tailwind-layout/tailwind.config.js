module.exports = {
  content: ["./src/**/*.html"],
  darkMode: 'class', // Menambahkan opsi dark mode
  theme: {
    extend: {
      colors: {
        primary: '#CB9DF0',
        secondary: '#ecd9cd',
      },
      fontFamily: {
        sans: ['roboto', 'sans-serif'],
      },
    },
  },
}